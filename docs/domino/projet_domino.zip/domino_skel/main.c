#include <stdio.h>
#include <stdlib.h>
#include "domino.h"
#include "liste.h"
#include "backtracking.h"
#include "parser.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: chainedom dominos.txt\n");
        exit(EXIT_FAILURE);
    }
    Liste sac = parse_file(argv[1]);
    printf("Liste initiale :\n");
    print_liste(&sac);
    printf("\n");

    Liste chaine = nouvelle_liste();
    bool success = bt_chaine(&sac, &chaine);
    if (success) {
        printf("Construction réussie :\n");
        print_liste(&chaine);
        printf("\n");
    } else {
        printf("Construction impossible.\n");
    }
    free_liste(&sac);
    free_liste(&chaine);

    return EXIT_SUCCESS;
}
