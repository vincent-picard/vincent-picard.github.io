#include <stdbool.h>
#include <stdlib.h>
#include "domino.h"
#include "liste.h"

bool bt_chaine(Liste *sac, Liste *chaine) {
    // PLACE HOLDER (A SUPPRIMER) 
    return false;
    // FIN PLACE HOLDER
    
    if (sac->premier == NULL) {
        // A COMPLETER
    } else {
        // Cette boucle parcourt les maillons du sac :
        for (Maillon *m = sac->premier; m != NULL; m = m->suivant) {
            if (chaine->dernier == NULL || domino_possible_avec_rotation(chaine->dernier->d, &(m->d))) {
                // A COMPLETER
                if (bt_chaine(sac, chaine)) {
                    // A COMPLETER
                } else {
                    // A COMPLETER
                }
            }
        }
        return false;
    }
}
