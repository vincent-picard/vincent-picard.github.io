#ifndef BACKTRACKING_H
#define BACKTRACKING_H

#include <stdbool.h>
#include "domino.h"
#include "liste.h"

bool bt_chaine(Liste *sac, Liste *chaine);

#endif
