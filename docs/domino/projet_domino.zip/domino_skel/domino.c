#include <stdio.h>
#include <stdbool.h>
#include "domino.h"


Domino domino(int x, int y) {
    Domino res = {.x = x, .y = y};
    return res;
}

bool domino_possible(Domino a, Domino b) {
    // A COMPLETER
    return false; // A SUPPRIMER
}

bool domino_possible_avec_rotation(Domino a, Domino *b) {
    // A COMPLETER
    return false; // A SUPPRIMER
}

void print_domino(Domino d) {
    printf("[%d;%d]", d.x, d.y);
}
