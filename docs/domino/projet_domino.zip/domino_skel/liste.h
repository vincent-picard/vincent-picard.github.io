#ifndef LISTE_H
#define LISTE_H

#include "domino.h"

struct maillon_s {
    Domino d;
    struct maillon_s *suivant;
    struct maillon_s *precedent;
};
typedef struct maillon_s Maillon;

struct liste_s {
    Maillon *premier;
    Maillon *dernier;
};
typedef struct liste_s Liste;

Liste nouvelle_liste();

// Ajoute le domino d en fin de liste l
void append(Liste *l, Domino d);
// Supprime et retourne le dernier domino de la liste l supposée non vide
Domino pop(Liste *l);

// Libère la mémoire allouée pour tous les maillons de la liste (mais pas
// la structure de liste en elle-même
void free_liste(Liste *l);

// Enleve un maillon de la liste l donné sous forme de pointeur
// Cette opération ne modifie pas m et ne libère pas m (le but est de pouvoir le remettre avec
// la fonction remettre_maillon)
void enlever_maillon(Liste *l, Maillon *m);

// Remet dans la liste le maillon m qui vient d'etre enlevé avec enlever_maillon
void remettre_maillon(Liste *l, Maillon *m);

void print_liste(const Liste *l);
#endif
