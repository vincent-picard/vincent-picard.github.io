#include <stdio.h>
#include <stdlib.h>
#include "liste.h"
#include "domino.h"

#define BUFFER_SIZE 50

Liste parse_file(char *filename) {
    Liste l = nouvelle_liste();
    FILE *file = fopen(filename, "r"); 

    char buffer[BUFFER_SIZE];
    int i = 0; // position dans le buffer
    int c; // caractère lu

    int x, y; // Valeurs domino
              //
    while ((c = getc(file)) != EOF) {
        if (c == ' ') { // ignorer les espaces
        
        } else if (c == ',') {
            buffer[i] = '\0';
            x = atoi(buffer);
            i = 0;
        } else if (c == '\n') {
            buffer[i] = '\0';
            y = atoi(buffer);
            i = 0;
            append(&l, domino(x, y));
        } else {
            buffer[i] = c;
            i += 1;
            if (i >= BUFFER_SIZE - 1) { // buffer overflow
                exit(EXIT_FAILURE);
            }
        }
    }
    return l;
}

