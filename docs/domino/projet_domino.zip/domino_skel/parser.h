#ifndef PARSER_H
#define PARSER_H

#include "liste.h"

Liste parse_file(char *filename);

#endif
