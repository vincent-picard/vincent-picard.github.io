#ifndef DOMINO_H
#define DOMINO_H

#include <stdbool.h>

struct domino_s {
    int x; // Partie gauche
    int y; // Partie droite
};
typedef struct domino_s Domino;

Domino domino(int x, int y);
bool domino_possible(Domino a, Domino b);
bool domino_possible_avec_rotation(Domino a, Domino *b);

void print_domino(Domino d);
#endif
