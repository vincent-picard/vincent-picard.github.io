#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "liste.h"
#include "domino.h"

Liste nouvelle_liste() {
    Liste res = {.premier = NULL, .dernier = NULL};
    return res;
}

void append(Liste *l, Domino d) {
    // A COMPLETER
}

Domino pop(Liste *l) {
    // A COMPLETER
}

void free_liste(Liste *l) {
    while(l->premier != NULL) {
        pop(l);
    }
}

void enlever_maillon(Liste *l, Maillon* m) {
    // A COMPLETER
}

void remettre_maillon(Liste *l, Maillon *m) {
    // A COMPLETER
}

void print_liste(const Liste *l) {
    for (Maillon* m = l->premier; m != NULL; m = m->suivant) {
        print_domino(m->d);
    }
    printf("\n");
}
