import re
import math

def lire_phrases(nom_fichier):
    phrases = None
    with open(nom_fichier, 'r') as fichier:
        contenu = fichier.read()
        print("Ouverture du fichier", nom_fichier, "réussie. ", len(contenu), "caractères lus.")
        # Passe tout en minuscules
        contenu = contenu.lower()
        # Efface certains caractères du texte
        contenu = re.sub('[\n\"\'\\-\,:;\\(\\)\\_«»]', ' ', contenu)
        # Efface les espaces superflus
        contenu = re.sub(' +', ' ', contenu)
        # Enleve les accents de la langue française
        contenu = re.sub('[éèê]', 'e', contenu)
        contenu = re.sub('[àâ]', 'a', contenu)
        contenu = re.sub('ô', 'o', contenu)
        contenu = re.sub('ù', 'u', contenu)
        contenu = re.sub('î', 'i', contenu)
        contenu = re.sub('ç', 'c', contenu)

        # Coupe le texte en phrases selon le caractère . ! ou ?
        phrases = re.split('[\.\\?!]', contenu)
        # Efface les espaces en trop au debut et a la fin
        phrases = [p.strip() for p in phrases if len(p) > 5]
        fichier.close()
    return phrases


p1 = lire_phrases('miserables.txt')
p2 = lire_phrases('scarlet.txt')
print("Le corpus français contient", len(p1), "phrases")
print("Le corpus anglais contient", len(p2), "phrases")
alpha = "abcdefghijklmnopqrstuvwxyz"

def bigramme(phrase):
    dictionnaire = {}
    for u in alpha:
        for v in alpha:
            dictionnaire[u, v] = 0
    n = len(phrase)
    for i in range(n-1):
        if phrase[i] in alpha and phrase[i+1] in alpha:
            dictionnaire[phrase[i], phrase[i+1]] += 1
    return dictionnaire

def taille_bigramme(b):
    s = 0
    for u in alpha:
        for v in alpha:
            s += b[u, v]
    return s

def dist(b1, b2):
    d = 0
    n1 = taille_bigramme(b1)
    n2 = taille_bigramme(b2)
    for u in alpha:
        for v in alpha:
            d += (b1[u,v]/n1 - b2[u, v]/n2) ** 2
    return d

def plusprochevoisin(phrase):
    d = math.inf
    ppv = None
    bcible = bigramme(phrase)
    for s in p1:
        b = bigramme(s)
        d2 = dist(bcible, b)
        if d2 < d:
            d = d2
            ppv = s
    for s in p2:
        b = bigramme(s)
        d2 = dist(bcible, b)
        if d2 < d:
            d = d2
            ppv = s
    return (d, ppv)

s = input("Entrez une phrase : ")
print(plusprochevoisin(s))
