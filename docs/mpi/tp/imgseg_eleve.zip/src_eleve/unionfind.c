#include <stdlib.h>
#include "unionfind.h"
#include <assert.h>

void uf_init(unionfind* u, int n) {
    u->n = n;
    u->cc = n;
    u->parent = malloc(sizeof(int) * n);
    u->h = malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++) {
        u->parent[i] = i;
        u->h[i] = 0;
    }
}

int uf_find(unionfind* u, int x) {
    // A COMPLETER
}

void uf_union(unionfind* u, int x, int y) {
    // A COMPLETER
}


void uf_destroy(unionfind* u) {
    free(u->parent);
    free(u->h);
}
