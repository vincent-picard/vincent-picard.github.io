#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

/* Implémentation de la structure de pile d'entiers */
/* Concrètement on utilise un tableau + un indice de sommet de pile */

#define MAXSTACK 64

struct stack_s {
    int data[MAXSTACK];
    int size;
};

typedef struct stack_s stack;

void stack_init(stack *s) {
    assert(s != NULL);
    s->size = 0;
}

bool stack_empty(stack *s) {
    assert(s != NULL);
    return s->size == 0;
}

int stack_size(stack *s) {
    assert(s != NULL);
    return s->size;
}

void stack_push(stack *s, int val) {
    assert(s != NULL && s->size < MAXSTACK);
    s->data[s->size] = val;
    s->size += 1;
}

int stack_pop(stack *s) {
    assert(s != NULL && s->size > 0);
    s->size -= 1;
    return s->data[s->size];
}

/* Implémentation de la mise à jour de la pile en fonction des tokens */

void update_stack(stack *s, char token[]) {
    assert(strlen(token) > 0);
    if (token[0] == '+') {
        if (stack_size(s) >= 2) {
            int y = stack_pop(s);
            int x = stack_pop(s);
            stack_push(s, x + y);
        } else {
            fprintf(stderr, "Erreur de syntaxe\n");
            exit(EXIT_FAILURE);
        }
    } else if (token[0] == 'x') {
        if (stack_size(s) >= 2) {
            int y = stack_pop(s);
            int x = stack_pop(s);
            stack_push(s, x * y);
        } else {
            fprintf(stderr, "Erreur de syntaxe\n");
            exit(EXIT_FAILURE);
        }
    } else {
        stack_push(s, atoi(token));
    }
}

/* STAGE 1 */
/*
int main(int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        printf("%d\n", atoi(argv[i]));
    }
    return EXIT_SUCCESS;
}
*/

/* STAGE 2 */
/*
int main(int argc, char **argv) {
    stack *s = malloc(sizeof(stack));
    stack_init(s);
    for (int i = 1; i < argc; i++) {
        stack_push(s, atoi(argv[i]));
    }
    while (!stack_empty(s)) {
        int val = stack_pop(s);
        printf("%d\n", val);
    }
    free(s);
    return EXIT_SUCCESS;
}
*/

/* STAGE 3 */
int main(int argc, char **argv) {
    stack *s = malloc(sizeof(stack));
    stack_init(s);
    for (int i = 1; i < argc; i++) {
        update_stack(s, argv[i]);
    }
    if (stack_size(s) == 1) {
        printf("Résultat : %d \n", stack_pop(s));
    } else {
        fprintf(stderr, "Erreur de syntaxe\n");
        exit(EXIT_FAILURE);
    }
    free(s);
    return EXIT_SUCCESS;
}
