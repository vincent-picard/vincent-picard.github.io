#ifndef KDTREE_H
#define KDTREE_H

#include <stdbool.h>

#define KMAX 16

struct noeud_s {
    int vecteur[KMAX];
    int etiquette;
    struct noeud_s *gauche;
    struct noeud_s *droite;
};

typedef struct noeud_s * kdtree;

// Construit sur le tas un nouveau noeud et l'initialise
// avec le vecteur u de dimension k, le fils gauche et le fils droit
kdtree kdtree_noeud(int *u, int k, int etiquette, kdtree gauche, kdtree droite);

// Affiche le kdtree contenant des vecteurs de dimension k
void kdtree_print(kdtree a, int k);

// Libère la mémoire allouée pour l'ensemble des noeuds d'un kdtree
void kdtree_destroy(kdtree a);

// Renvoie la hauteur du kdtree
int kdtree_hauteur(kdtree a);

// Renvoie la taille du kdtree
int kdtree_taille(kdtree a);

// Cherche le vecteur u dans le kdtree a
// Si u est trouvé, renvoie l'étiquette associée
// Si u n'existe pas, renvoie -1
int kdtree_find(kdtree a, int *u, int k);

kdtree kdtree_insere(kdtree a, int *u, int k, int etiquette);

// Renvoie le noeud de l'arbre contenant le vecteur le plus proche de u. Si l'arbre est vide, renvoie NULL. prof est la profondeur du noeud considéré, doit être appelé initialement avec prof=0
kdtree kdtree_ppv(kdtree a, int prof, int *u, int k);

#endif
