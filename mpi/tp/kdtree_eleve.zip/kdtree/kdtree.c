#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <stdio.h>

#include "kdtree.h"

kdtree kdtree_noeud(int *u, int k, int etiquette, kdtree gauche, kdtree droite) {
    // A COMPLETER
}

void kdtree_print_aux(kdtree a, int k, int indent) {
    for (int i = 0; i < indent; i++) {
        if (i == indent - 1) {
            printf("L-->");
        } else {
            printf("    ");
        }
    }
    if (a == NULL) {
        printf("VIDE\n");
    } else {
        printf("NOEUD ");
        for (int i = 0; i < k; i++) {
            printf("%d ", a->vecteur[i]);
        }
        printf("\n");
        kdtree_print_aux(a->gauche, k, indent+1);
        kdtree_print_aux(a->droite, k, indent+1);
    }
}

void kdtree_print(kdtree a, int k) {
    kdtree_print_aux(a, k, 0);
}

void kdtree_destroy(kdtree a) {
    if (a != NULL) {
        kdtree_destroy(a -> gauche);
        kdtree_destroy(a -> droite);
        free(a);
    }
}

int kdtree_hauteur(kdtree a) {
    // A COMPLETER
}

int kdtree_taille(kdtree a) {
    // A COMPLETER
}

bool egal_vect(int *u, int *v, int k) {
    for (int i = 0; i < k; i++) {
        if (u[i] != v[i]) return false;
    }
    return true;
}

int kdtree_find(kdtree a, int *u, int k) {
    // A COMPLETER
}

kdtree kdtree_insere(kdtree a, int *u, int k, int etiquette) {
        // A COMPLETER

        // 1 - Localiser l'emplacement vide où aura lieu l'insertion
        // Ainsi que son noeud parent

        // 2 - Inserer une feuille dans cet emplacement vide
}


int carre(int x) {
    return (x * x);
}

// Renvoie le carré de la distance euclidienne entre u et v
int distc(int *u, int *v, int k) {
    // A COMPLETER
}

// Renvoie le noeud entre x et y qui contient le point le plus proche
// de u
// x doit être non NULL
// y peut être NULL auquel cas on renvoie x

kdtree best_node(int* u, int k, kdtree x, kdtree y) {
    // A COMPLETER
}

// Renvoie le noeud de l'arbre a qui contient le vecteur le plus
// proche de u. Si l'arbre est vide, renvoie NULL
kdtree kdtree_ppv(kdtree a, int prof, int *u, int k) {
    // A COMPLETER
}

