#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "kdtree.h"

#define NMAX 8192

void print_vect(int *u, int k) {
    printf("[");
    for (int i = 0; i < k; i++) {
        printf("%d", u[i]);
        if (i < k - 1) printf(", ");
    }
    printf("]");
}

void test_insere_find() {
    int data[][2] = {{0,1}, {2, 5}, {5, 7}, {-2, 7}};
    kdtree a = NULL;

    // A COMPLETER

    kdtree_destroy(a);
}

void test_ppv() {
    int data[][2] = {{0,1}, {2, 5}, {5, 7}, {-2, 7}};
    int query[][2] = {{5, 8}, {-3, 8}, {0, 0}};
    kdtree a = NULL;
    for (int i = 0; i < 4; i++) {
        a = kdtree_insere(a, data[i], 2, i);
    }
    kdtree_print(a, 2);
    for (int i = 0; i < 3; i++) {
        kdtree ppv = kdtree_ppv(a, 0, query[i], 2);
        printf("Le point le plus proche de ");
        print_vect(query[i], 2);
        printf(" est ");
        print_vect(ppv->vecteur, 2);
        printf("\n");
    }
    kdtree_destroy(a);
}

// Cette fonction charge un fichier csv d'analyses de vin et enregistre les vecteurs
// de dimension 11 dans le tableau vecteurs et les étiquettes correspondantes dans le
// tableau etiquettes. Ces deux tableaux doivent être assez grands pour contenir les
// données.
// Renvoie le nombre d'exemples chargés.
int load_wine_file(char *filename, int vecteurs[][11], int etiquettes[]) {
    FILE *fichier = fopen(filename, "r");
    int i = 0; // Compteur d'exemples 
    float u[11];
    int note;
    int n = fscanf(fichier, "%f;%f;%f;%f;%f;%f;%f;%f;%f;%f;%f;%d\n",
                    &u[0], &u[1], &u[2], &u[3], &u[4], &u[5], &u[6], 
                    &u[7], &u[8], &u[9], &u[10], &note);
    while (n != EOF) {
        assert(n == 12);
        for (int j = 0; j < 11; j++) {
            vecteurs[i][j] = (int) (1000. * u[j]);
        }
        etiquettes[i] = note;
        i += 1;
        n = fscanf(fichier, "%f;%f;%f;%f;%f;%f;%f;%f;%f;%f;%f;%d\n",
                    &u[0], &u[1], &u[2], &u[3], &u[4], &u[5], &u[6], 
                    &u[7], &u[8], &u[9], &u[10], &note);

    }
    fclose(fichier);
    return i;
}

int main() {
    //test_insere_find();
    //test_ppv();
//
    return EXIT_SUCCESS;
}
