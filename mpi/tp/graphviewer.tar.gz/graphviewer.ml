Random.self_init ();;

(* creates a random string of length n *)
let random_string n =
    let random_char () =
        let r = Random.int 26 in
        Char.chr (r + 65)
    in
    String.init n (fun _ -> random_char ()) 
;;

let test_random_string () =
    print_string (random_string 50);
    print_newline ()
;;

(* generates a random file path *)
let random_filepath ?(prefix = "/tmp/") ?(suffix = ".txt") name =
    prefix ^ name ^ "_" ^ (random_string 30) ^ suffix
;;

let test_random_filepath () =
    print_string (random_filepath "test");
    print_newline ()
;;

(* Viewers *)

(* Affiche un graphe non orienté depuis sa matrice d'adjacence *)
let undirected_matrix m =
    let n = Array.length m in
    let filepath = random_filepath ~suffix:".dot" "graphviewer" in
    let file = open_out filepath in

    Printf.fprintf file "graph {\n";
    Printf.fprintf file "node[shape=circle]\n";
    for i = 0 to n - 1 do for j = i + 1 to n - 1 do
        if m.(i).(j) = 1 then
            Printf.fprintf file "%d -- %d\n" i j 
    done done;
    Printf.fprintf file "}\n";

    close_out file;
    ignore (Sys.command ("xdot "^filepath))
;;


(* Affiche un graphe orienté depuis sa matrice d'adjacence *)
let directed_matrix m =
    let n = Array.length m in
    let filepath = random_filepath ~suffix:".dot" "graphviewer" in
    let file = open_out filepath in

    Printf.fprintf file "digraph {\n";
    Printf.fprintf file "node[shape=circle]\n";
    for i = 0 to n - 1 do for j = 0 to n - 1 do
        if (m.(i).(j) = 1) then
            Printf.fprintf file "%d -> %d\n" i j 
    done done;
    Printf.fprintf file "}\n";

    close_out file;
    ignore (Sys.command ("xdot "^filepath))
;;

(* Affiche un graphe non orienté pondéré depuis sa matrice de poids *)
(* Les poids sont des flottants, la valeur +inf est utilisée pour marquer
   l'absence d'arête *)
let undirected_weighted_matrix m =
    let n = Array.length m in
    let filepath = random_filepath ~suffix:".dot" "graphviewer" in
    let file = open_out filepath in

    Printf.fprintf file "graph {\n";
    Printf.fprintf file "node[shape=circle]\n";
    for i = 0 to n - 1 do for j = i + 1 to n - 1 do
        if not (m.(i).(j) = Float.infinity) then
            Printf.fprintf file "%d -- %d [ label=\"%F\"  ]\n" i j m.(i).(j) 
    done done;
    Printf.fprintf file "}\n";

    close_out file;
    ignore (Sys.command ("xdot "^filepath))
;;

(* Affiche un graphe orienté pondéré depuis sa matrice de poids *)
(* Les poids sont des flottants, la valeur +inf est utilisée pour marquer
   l'absence d'arête *)
let directed_weighted_matrix m =
    let n = Array.length m in
    let filepath = random_filepath ~suffix:".dot" "graphviewer" in
    let file = open_out filepath in

    Printf.fprintf file "digraph {\n";
    Printf.fprintf file "node[shape=circle]\n";
    for i = 0 to n - 1 do for j = 0 to n - 1 do
        if not (m.(i).(j) = Float.infinity) then
            Printf.fprintf file "%d -> %d [ label=\"%F\"  ]\n" i j m.(i).(j) 
    done done;
    Printf.fprintf file "}\n";

    close_out file;
    ignore (Sys.command ("xdot "^filepath))
;;


(* Affiche un graphe non orienté donne sous forme de listes d'adjacence *)
let undirected_adjlist adj =
    let n = Array.length adj in
    let filepath = random_filepath ~suffix:".dot" "graphviewer" in
    let file = open_out filepath in

    Printf.fprintf file "graph {\n";
    Printf.fprintf file "node[shape=circle]\n";
    for i = 0 to n - 1 do
        let rec traite_voisins l = match l with
        | [] -> ()
        | j::q when j > i -> begin
            Printf.fprintf file "%d -- %d\n" i j;
            traite_voisins q
        end
        | _::q -> traite_voisins q
        in traite_voisins adj.(i)
    done;
    Printf.fprintf file "}\n";

    close_out file;
    ignore (Sys.command ("xdot "^filepath))
;;


(* Affiche un graphe orienté donne sous forme de listes d'adjacence *)
let directed_adjlist adj =
    let n = Array.length adj in
    let filepath = random_filepath ~suffix:".dot" "graphviewer" in
    let file = open_out filepath in

    Printf.fprintf file "digraph {\n";
    Printf.fprintf file "node[shape=circle]\n";
    for i = 0 to n - 1 do
        let rec traite_voisins l = match l with
        | [] -> ()
        | j::q -> begin
            Printf.fprintf file "%d -> %d\n" i j;
            traite_voisins q
        end
        in traite_voisins adj.(i)
    done;
    Printf.fprintf file "}\n";

    close_out file;
    ignore (Sys.command ("xdot "^filepath))
;;

(* Affiche un automate fini *)
(* Paramètres :
    - t : une table de transitions sous le format suivant :
        chaque t.(i) contient une liste de couples (c, j) signifiant
        que depuis l'état i en lisant c on arrive dans l'état j
    - init : liste d'états initiaux
    - final : liste d'états finaux
*)
let automaton t init final =
    let n = Array.length t in
    let filepath = random_filepath ~suffix:".dot" "graphviewer" in
    let file = open_out filepath in

    Printf.fprintf file "digraph {\n";
    Printf.fprintf file "node[shape=circle]\n";

    let rec traite_sommet_final s =
        Printf.fprintf file "%d [shape=doublecircle]\n" s
    in
    List.iter traite_sommet_final final;

    let rec traite_sommet_init s =
        Printf.fprintf file "invisible%d [shape=plaintext label=\"\"]\n" s;
        Printf.fprintf file "invisible%d -> %d\n" s s
    in
    List.iter traite_sommet_init init;

    for i = 0 to n - 1 do
        let rec traite_voisins l = match l with
        | [] -> ()
        | (c, j)::q -> begin
            Printf.fprintf file "%d -> %d [label=%c]\n" i j c;
            traite_voisins q
        end
        in traite_voisins t.(i)
    done;
    Printf.fprintf file "}\n";

    close_out file;
    ignore (Sys.command ("xdot "^filepath))
;;


