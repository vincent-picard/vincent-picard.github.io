type regexp = 
    | Vide
    | Epsilon
    | Lettre of char
    | Concat of regexp * regexp
    | Union of regexp * regexp
    | Etoile of regexp

let rec print_regexp e = match e with
    | Vide -> print_string "0"
    | Epsilon -> print_string "€"
    | Lettre c -> print_char c
    | Concat (e1, e2) -> begin
        print_char '(';
        print_regexp e1;
        print_char '.';
        print_regexp e2;
        print_char ')'
    end
    | Union (e1, e2) -> begin
        print_char '(';
        print_regexp e1;
        print_string " | ";
        print_regexp e2;
        print_char ')'
    end
    | Etoile e1 -> begin
        print_char '(';
        print_regexp e1;
        print_string ")*"
    end
;;

