(* Pour ce TP on travaillera avec dune *)

(* Dans le terminal :
    - 'dune utop' : ouver un interprete qui connait le module Regexp : à utiliser avec VSCode
    - 'dune build' : compiler ce programme
    - 'dune exec tp_regexp' : compiler et exécuter ce programme (build n'est alors pas necessaire)
    - 'dune clean' : supprime tous les fichiers de compilation
    *)

open Regexp;; (* permet d'éviter de taper Regexp.XXX partout *)

(* Le module Regexp est maintenant ouvert, vous pouvez utiliser
   tous les types et fonctions définies dans l'interface regexp.mli *)
(* Pour les curieuses et curieux : l'implémentation est dans regexp.ml *)

let _ = print_regexp (Lettre 'a');;
