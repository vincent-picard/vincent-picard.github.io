#include <stdlib.h>
#include "unionfind.h"
#include <assert.h>

void uf_init(unionfind* u, int n) {
    u->n = n;
    u->cc = n;
    u->parent = malloc(sizeof(int) * n);
    u->h = malloc(sizeof(int) * n);
    for (int i = 0; i < n; i++) {
        u->parent[i] = i;
        u->h[i] = 0;
    }
}

int uf_find(unionfind* u, int x) {
    assert(0 <= x && x < u->n);
    if (u->parent[x] == x) { // si x racine
        return x;
    } else {
        int r = uf_find(u, u->parent[x]);
        u->parent[x] = r; // compression des chemins
        return r;
    }
}

void uf_union(unionfind* u, int x, int y) {
    assert(0 <= x && x < u->n);
    assert(0 <= y && y < u->n);
    int rx = uf_find(u, x);
    int ry = uf_find(u, y);
    if (rx != ry) {
        if (u->h[rx] < u->h[ry]) {
            u->parent[rx] = ry;
        } else if (u->h[ry] < u->h[rx]) {
            u->parent[ry] = rx;
        } else {
            u->parent[rx] = ry;
            u->h[ry] += 1;
        }
        u->cc -= 1;
    }
}

void uf_destroy(unionfind* u) {
    free(u->parent);
    free(u->h);
}
