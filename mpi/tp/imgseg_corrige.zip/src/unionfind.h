#ifndef UNIONFIND_H
#define UNIONFIND_H

struct unionfind_s {
    int n; // nombre d'éléments numérotés de 0 à n-1
    int cc; // nombre de composantes connexes
    int* parent; // parent de chaque element
    int* h; // hauteur du sous-arbre
};

typedef struct unionfind_s unionfind;

extern void uf_init(unionfind* u, int n);

extern int uf_find(unionfind* u, int x);

extern void uf_union(unionfind* u, int x, int y);

extern void uf_destroy(unionfind* u);

#endif

