#include "image.h"
#include "unionfind.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
    image* img = load_ppm_file(argv[1]);
    double tol = strtod(argv[2], NULL);
    printf("Largeur : %d\n", img->width);
    printf("Hauteur : %d\n", img->height);
    printf("Maxval : %d\n", img->maxval);
    printf("Tolerance : %f\n", tol);
    unionfind uf;
    uf_init(&uf, img->width * img->height);
    printf("Nb composantes : %d\n", uf.cc);
    for (int i = 1; i < img->height - 1; i++) {
        for (int j = 1; j < img->width - 1; j++) {
            if (pixel_distance(img, i, j, i-1, j) < tol) {
                uf_union(&uf, i * img->width + j, (i-1) * img-> width + j);
            }
            if (pixel_distance(img, i, j, i+1, j) < tol) {
                uf_union(&uf, i * img->width + j, (i+1) * img-> width + j);
            }
            if (pixel_distance(img, i, j, i, j-1) < tol) {
                uf_union(&uf, i * img->width + j, i * img->width + j-1);
            }
            if (pixel_distance(img, i, j, i, j+1) < tol) {
                uf_union(&uf, i * img->width + j, i * img-> width + j+1);
            }
        }
    }
    printf("Nb composantes : %d\n", uf.cc);
    image* img2 = copy_image(img);
    for (int i = 0; i < img->height; i++) {
        for (int j = 0; j < img->width; j++) {
            int k = uf_find(&uf, i * img -> width + j);
            set_pixel(img2, RED, i, j, get_pixel(img, RED, k / img->width, k % img->width));
            set_pixel(img2, GREEN, i, j, get_pixel(img, GREEN, k / img->width, k % img->width));
            set_pixel(img2, BLUE, i, j, get_pixel(img, BLUE, k / img->width, k % img->width));
        }
    }
    save_ppm_file("segments.ppm", img2);
    uf_destroy(&uf);
    destroy_image(img);
    destroy_image(img2);
    return EXIT_SUCCESS;
}
