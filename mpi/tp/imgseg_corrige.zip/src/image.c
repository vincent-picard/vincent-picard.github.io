#include "image.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>
#include <math.h>

void destroy_image(image* img) {
    free(img->data);
    free(img);
}

bool check_magicnumber(FILE* file, char* magic) {
    char buffer[3];
    int pos = 0;
    int c = getc(file);
    while (c != EOF && pos < 2) {
        buffer[pos] = c;
        pos += 1;
        c = getc(file);
    }
    ungetc(c, file);
    if (pos == 2) {
        buffer[pos] = '\0';
        return strcmp(buffer, magic) == 0;
    } else {
        return false;
    }
}

int ignore_blanks(FILE* file) {
    int n = 0; // number of ignored chars
    int c = getc(file);
    while (c != EOF && (c == '\011' || c == '\012' || c == '\013' || c == '\015' || c == '\040')) {
        fputc(c, file);
        n += 1;
        c = getc(file);
    }
    ungetc(c, file);
    if (c == EOF) {
        return -1;
    } else {
        return n;
    }
}

int read_int(FILE* file) {
    char buffer[101];
    int pos = 0;
    int c = getc(file);
    while (c != EOF && ('0' <= c && c <= '9') && pos < 100) {
        buffer[pos] = c;
        pos += 1;
        c = getc(file);
    }
    ungetc(c, file);
    buffer[pos] = '\0';
    return atoi(buffer);
}

int load_pixels_1byte(FILE* file, uint16_t* data) {
    int n = 0; // nb read values
    int c = getc(file);
    while (c != EOF) {
        data[n] = (uint16_t) c;
        n += 1;
        c = getc(file);
    }
    //ungetc(c, file);
    return n;
}

int load_pixels_2bytes(FILE* file, uint16_t* data) {
    int n = 0; // nb read values
    int c = getc(file);
    while (c != EOF) {
        int c2 = getc(file);
        data[n] = (((unsigned int) c) << 8) + (unsigned int) c2;
        n += 1;
        c = getc(file);
    }
    //ungetc(c, file);
    return n;
}

image* load_ppm_file(char* filename) {
    image* img = malloc(sizeof(image));
    FILE* file = fopen(filename, "r");
    if (!check_magicnumber(file, "P6")) {
        fprintf(stderr, "bad magic number\n");
        exit(EXIT_FAILURE);
    }
    ignore_blanks(file);
    img->width = read_int(file);
    ignore_blanks(file);
    img->height = read_int(file);
    ignore_blanks(file);
    img->maxval = read_int(file);
    getc(file); // ignore one byte
    uint16_t* data = malloc(16 * 3 * img->width * img->height);
    img->data = data;
    if (img->maxval < 256) {
        load_pixels_1byte(file, data);
    } else {
        load_pixels_2bytes(file, data);
    }
    fclose(file);
    return img;
}

void save_ppm_file(char* filename, image* img) {
    FILE* file = fopen(filename, "w");
    fprintf(file, "P6\n");
    fprintf(file, "%d %d\n", img->width, img->height);
    fprintf(file, "%d\n", img->maxval);
    for (int i = 0; i < img->width * img->height; i++) {
        if (img->maxval < 256) {
            putc(img->data[3*i], file);
            putc(img->data[3*i+1], file);
            putc(img->data[3*i+2], file);
        } else {
            putc(img->data[3*i] >> 8, file);
            putc(img->data[3*i] % 256, file);
            putc(img->data[3*i+1] >> 8, file);
            putc(img->data[3*i+1] % 256, file);
            putc(img->data[3*i+2] >> 8, file);
            putc(img->data[3*i+2] % 256, file);
        }
    }
    fclose(file);
}

image* copy_image(image *img) {
    image* cpy = malloc(sizeof(image));
    uint16_t* cpy_data = malloc(16 * 3 * img->width * img->height);
    cpy->width = img->width;
    cpy->height = img->height;
    cpy->maxval = img->maxval;
    cpy->data = cpy_data;
    for (int i = 0; i < 3 * img->width * img->height; i++) {
        cpy_data[i] = img->data[i];
    }
    return cpy;
}

const int RED = 0;
const int GREEN = 1;
const int BLUE = 2;

uint16_t get_pixel(image* img, int channel, int i, int j) {
    assert(0 <= i && i < img->height);
    assert(0 <= j && j < img->width);
    
    int k = (i * img->width + j) * 3 + channel;
    return img->data[k];
}


void set_pixel(image* img, int channel, int i, int j, uint16_t val) {
    assert(0 <= i && i < img->height);
    assert(0 <= j && j < img->width);
    
    int k = (i * img->width + j) * 3 + channel;
    img->data[k] = val;
}

double pixel_distance(image* img, int i1, int j1, int i2, int j2) {
    double r1 = get_pixel(img, RED, i1, j1); 
    double g1 = get_pixel(img, GREEN, i1, j1); 
    double b1 = get_pixel(img, BLUE, i1, j1); 
    double r2 = get_pixel(img, RED, i2, j2); 
    double g2 = get_pixel(img, GREEN, i2, j2); 
    double b2 = get_pixel(img, BLUE, i2, j2); 

    return sqrt(0.3 * (r1 - r2) * (r1 - r2) + 0.1 * (b1 - b2) * (b1 - b2) + 0.6 * (g1 - g2) * (g1 - g2))/(img->maxval);
}


