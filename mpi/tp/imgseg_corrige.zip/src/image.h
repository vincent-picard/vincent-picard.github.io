#ifndef IMAGE_H
#define IMAGE_H

#include <stdint.h>

struct image_s {
    int width; // image width in pixels
    int height; // image height in pixels
    int maxval; // color maximum value
    uint16_t* data; // image data
};

typedef struct image_s image;

extern void destroy_image(image* img);

extern image* copy_image(image* img);

extern image* load_ppm_file(char* filename);

extern void save_ppm_file(char* filename, image* img);

/* Pixel operations */

extern const int RED;
extern const int GREEN ;
extern const int BLUE;

extern uint16_t get_pixel(image* img, int channel, int i, int j);
extern void set_pixel(image* img, int channel, int i, int j, uint16_t val);

extern double pixel_distance(image* img, int i1, int j1, int i2, int j2);

#endif
