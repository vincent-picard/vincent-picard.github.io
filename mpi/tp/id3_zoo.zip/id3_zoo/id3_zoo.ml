(* Gestion du fichier de données *)
(* ----------------------------- *)

type dataset = {
    exemples: bool array list; (* valeur binaire des attributs *)
    etiquettes: int list; (* étiquette de chaque exemple *)
    attr_str: string array; (* nom des attributs *)
    etq_str: string array; (* nom des étiquettes *)
};;

let read_lines_file (filename:string) : string list =
    try
        let file = open_in filename in
        let rec read_lines () = 
            try
                let line = input_line file in
                line::(read_lines ())
            with
                End_of_file -> []
        in read_lines ()
    with
        _ -> failwith ("Erreur de lecture du fichier " ^ filename)
;;

(* Cette fonction sert spécifiquement à lire le fichier zoo.data *)
let read_zoo_file (filename:string) : dataset =
    let lines = read_lines_file filename in
    let records = List.map (String.split_on_char ',') lines in
    let n = List.length records in

    let attr = Array.make_matrix n 15 false in
    let etiquette = Array.make n (-1) in

    let parse_record i r =
        let r = Array.of_list r in
        etiquette.(i) <- (int_of_string r.(17)) - 1;
        let a = Array.append (Array.sub r 1 12) (Array.sub r 14 3) in
        let a = Array.map
                    (function
                        | "0" -> false
                        | "1" -> true
                        | _ -> failwith "zoo format error"
                    )
                    a
        in
        attr.(i) <- a
    in

    let rec enumerate_records i l = match l with
        | [] -> ()
        | h::t -> (parse_record i h; enumerate_records (i+1) t)
    in enumerate_records 0 records;
    {
        exemples = Array.to_list attr;
        etiquettes = Array.to_list etiquette;
        attr_str = [| "hair"; "feathers"; "eggs"; "milk"; "airborne"; "aquatic";
                      "predator"; "toothed"; "backbone"; "breathes"; "venomous";
                      "fins"; "tail"; "domestic"; "catsize"|];
        etq_str = [| "mammifère"; "oiseau"; "reptile"; 
                           "poisson"; "amphibien"; "insecte";
                           "autre invertebre" |]
    }
;;

let ds_zoo = read_zoo_file "zoo.data";;

(* Arbres de décision binaires *)
(* --------------------------- *)

type 'a abd =
  | Feuille of 'a
  | Noeud of int * ('a abd) * ('a abd) (* Noeud(k, g, d) avec k le numero de l'attribut concerne *)
;;

(* Fonction qui détermine l'étiquette d'une donnée à l'aide de l'arbre de décision *)
let rec classer (arbre: 'a abd) (t: bool array) : 'a =
    (* A COMPLETER *)
;;

(* Lance un programme interactif qui classifie à l'aide de l'arbre de décision *)
let mode_interactif dataset arbre =
    let rec classer a = match a with
    | Feuille n -> Printf.printf "Ton animal est un %s \n." dataset.etq_str.(n)
    | Noeud (k, g, d) -> begin
        Printf.printf "%s ? (répondre y/n) : " dataset.attr_str.(k);
        flush_all ();
        let traite_reponse reponse = match reponse with
        | 'n' -> classer g
        | 'y' -> classer d
        | _ -> classer a
        in
        Scanf.scanf "%c\n" traite_reponse
    end
    in classer arbre
;;

(* Si vous voulez tester le mode interactif avec un arbre factice :
let a_test = Noeud (7, Noeud(3, Feuille 0, Feuille 1), Feuille 4) in
mode_interactif ds_zoo a_test
*)

(* Fonctions utilitaires *)
(* --------------------- *)

(* Teste si tous les éléments d'une liste ont même valeur *)
let rec meme_valeur l = 
    (* A COMPLETER *)
;;

(* Renvoie la valeur maximale d'une liste d'entiers non vide *)
let rec max_liste l =
    (* A COMPLETER *)
;;

(* Prend une liste d'entiers compris entre 0 et maxval et
   effectue un décompte. Le résultat est un tableau tab
   dans lequel tab.(i) est le nombre d'occurrences de i *)
let decompte l maxval =
    (* A COMPLETER *)
;;

(* Prend une liste non vide d'entiers positifs et renvoie la valeur majoritaire *)
let majoritaire l =
    (* A COMPLETER *)
;;

(* Calculs d'entropie *)
(* ------------------ *)

let log2 x = log x /. log 2.0;;

(* Calcule l'entropie d'une liste d'étiquettes *)
(* exemple : entropie [1; 2; 1; 2] renvoie 1 *)
(* exemple : entropie [1; 1; 1; 1; 5; 5; 7; 11] renvoie 1.75 *)
let entropie l =
    (* A COMPLETER *)
;;

(* prend une liste d'exemples avec la liste d'étiquettes associée et sépare
   en deux sous-ensembles d'exemples, l'un pour lesquels l'attribut k est faux
   et l'autre pour lesquels l'attribut k est vrai *)
let rec separe exemples etiquettes k = match (exemples, etiquettes) with
    | ([], []) -> (([], []), ([], []))
    | (t1::h1, t2::h2) ->
            let ((ex_false, et_false), (ex_true, et_true)) = separe h1 h2 k in
            if t1.(k) then
                ((ex_false, et_false), (t1::ex_true, t2::et_true))
            else
                ((t1::ex_false, t2::et_false), (ex_true, et_true))
    | _ -> failwith "separe : bad format"
;;

(* calcule le gain de l'attribut k pour une liste d'exemples étiquetés *)
let gain exemples etiquettes k =
    (* A COMPLETER *)
;;

(* détermine l'attribut le plus discriminant parmi une liste d'attributs possibles *)
let plus_discriminant exemples etiquettes attributs =
  let gmax = ref Float.neg_infinity in
  let nmax = ref (-1) in
  let rec compare l = match l with
    | [] -> ()
    | t::q ->
       let g = gain exemples etiquettes t  in
       if g > !gmax 
       then (gmax := g; nmax := t; compare q)
       else compare q
  in compare attributs; !nmax
;;

let enleve l x =
  List.filter (fun y -> not (y = x)) l
;;
  

(* Algorithme ID3 *)
(* -------------- *)

let id3 (ds:dataset) : int abd =
    let n_attr = Array.length (List.hd ds.exemples) in
    let attr = List.init n_attr (fun i -> i) in
    let rec aux (s_ex, s_et) (sp_ex, sp_et) attr =
        if s_ex = [] then
            (* A COMPLETER *)
        else if attr = [] then
            (* A COMPLETER *)
        else if meme_valeur s_et then
            (* A COMPLETER *)
        else begin
            (* A COMPLETER *)
        end
    in
    aux (ds.exemples, ds.etiquettes) (ds.exemples, ds.etiquettes) attr
;;

(* Pour lancer le programme final *)
(*
let arbre_zoo = id3 ds_zoo;;
mode_interactif ds_zoo arbre_zoo;;
*)
