import re
import math

def lire_phrases(nom_fichier):
    phrases = None
    with open(nom_fichier, 'r') as fichier:
        contenu = fichier.read()
        print("Ouverture du fichier", nom_fichier, "réussie. ", len(contenu), "caractères lus.")
        # Passe tout en minuscules
        contenu = contenu.lower()
        # Efface certains caractères du texte
        contenu = re.sub('[\n\"\'\\-\,:;\\(\\)\\_«»]', ' ', contenu)
        # Efface les espaces superflus
        contenu = re.sub(' +', ' ', contenu)
        # Enleve les accents de la langue française
        contenu = re.sub('[éèê]', 'e', contenu)

        # Coupe le texte en phrases selon le caractère . ! ou ?
        phrases = re.split('[\.\\?!]', contenu)
        # Efface les espaces en trop au debut et a la fin
        phrases = [p.strip() for p in phrases if len(p) > 5]
        fichier.close()
    return phrases


p1 = lire_phrases('miserables.txt')
p2 = lire_phrases('scarlet.txt')
print("Le corpus français contient", len(p1), "phrases")
print("Le corpus anglais contient", len(p2), "phrases")
alpha = "abcdefghijklmnopqrstuvwxyz"

