import numpy as np
import matplotlib.pyplot as plt
import random

data_facile = np.genfromtxt('facile.csv', delimiter=',')
#data_moyen = np.genfromtxt('moyen.csv', delimiter=',')

def tracer(data, k):
    plt.figure()
    for k in range(k):
        x = [data[i][0] for i in range(len(data)) if data[i][2] == k]
        y = [data[i][1] for i in range(len(data)) if data[i][2] == k]
        plt.plot(x, y, '.', label = str(k))
    plt.legend(loc='right')

tracer(data_facile, 10)
#tracer(data_moyen, 20)

def barycentre(l):
    n = len(l)
    assert(n > 0)

    sx, sy = 0, 0
    for p in l:
        sx = sx + p[0]
        sy = sy + p[1]
    return (sx / n, sy / n)

def dist(a, b):
    return (((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5)

def plus_proche(a, l):
    n = len(l)
    assert(n > 0)

    imin = 0
    dmin = dist(a, l[0])
    for i in range(1, n):
        d = dist(a, l[i])
        if d < dmin:
            dmin = d
            imin = i
    return imin

def k_moyennes(k, l):
    assert(k >= 2)
    C = random.sample(list(l), k)
    for t in range(100):
        S = [ [] for i in range(k) ]
        for x in l:
            i = plus_proche(x, C)
            S[i].append(x)
        for i in range(k):
            if (S[i] != []):
                C[i] = barycentre(S[i])
    return (C, S)

def formater(C, S):
    l = []
    n = len(S)
    for i in range(n):
        for x in S[i]:
            l.append((x[0], x[1], i))
    return l

(Cf, Sf) = k_moyennes(10, data_facile)
tracer(formater(Cf, Sf), 10)

plt.show()
